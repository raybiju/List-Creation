
public class ListController {
	
	
	public static void main(String args[])
	{
		IntegerList il=new IntegerList();
		il.getList();
		
	}

}
